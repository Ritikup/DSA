package javaSamples;

public class Class {
	
	public static void main(String[] args) {
		System.out.println("HELLO WORLD");
		
	}

}
