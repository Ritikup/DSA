package dsaA;

import java.util.Scanner;

public class ArrayLoop {
	public static void main(String[] args) {
		creatingArr(345);

	}

	static void creatingArr(int num) {
		int[] alp = new int[3];

		// for (int i = 0; i < alp.length; i++) {
		alp[0] = num;

		// }

		// for (int i = 0; i < alp.length; i++) {
		System.out.print(alp[0] + " ");
	}

}
