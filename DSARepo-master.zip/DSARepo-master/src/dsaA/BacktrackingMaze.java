package dsaA;

import java.util.ArrayList;

public class BacktrackingMaze {

	public static void main(String[] args) {
		// System.out.println(count(4,4));
		System.out.println(findpathDiag("", 3, 3));
		
		/*
		boolean[][] maze= {
				{true,true,true},
				{true,false,true},
				{true,true,true}
		};
		stopPath("",maze,0,0);
		*/
		boolean[][] entermaze= {
				{true,true,true},
				{true,true,true},
				{false,true,true}
				};
		
		//restrictPath("",entermaze,0,0);

	}

	static int count(int r, int c) {
		if (r == 1 || c == 1) {
			return 1;
		}
		int l = count(r - 1, c);
		int right = count(r, c - 1);
		return l + right;
	}
	
	

	static void fpath(String p, int r, int c) {
		if(r==1 && c==1) {
			System.out.println(p);
			return;
		}
		if(r>1) {
			fpath(p+'D',r-1,c);
		}
		if(c>1) {
			fpath(p+'R',r,c-1);
		}
		
	}
	
	

	static ArrayList<String> findPathsAL(String p, int r, int c) {
		if (r == 1 && c == 1) {
			ArrayList<String> paths = new ArrayList<String>();
			paths.add(p);

			return paths;
		}

		ArrayList<String> paths = new ArrayList<String>();

		if (r > 1) {
			paths.addAll(findPathsAL(p + 'D', r - 1, c));

		}
		if (c > 1) {
			paths.addAll(findPathsAL(p + 'R', r, c - 1));
		}
		return paths;
	}

	static ArrayList<String> findpathDiag(String p, int r, int c) {
		if (r == 1 && c == 1) {
			ArrayList<String> paths = new ArrayList<>();
			paths.add(p);
			return paths;
		}

		ArrayList<String> paths = new ArrayList<>();

		if (r > 1 && c > 1) {
			paths.addAll(findpathDiag(p + 'D', r - 1, c - 1));

		}
		if (r > 1) {
			paths.addAll(findpathDiag(p + 'V', r - 1, c));

		}
		if (c > 1) {
			paths.addAll(findpathDiag(p + 'H', r, c - 1));
		}
		return paths;
	}
	
	static void stopPath(String p,boolean[][] maze, int r, int c) {
		if (r == maze.length-1 && c == maze[0].length-1) {
			
			System.out.println(p);
			return;
		}

		

		if(maze[r][c]==false) {
			return;
		}
		if (r < maze.length-1 && c < maze[0].length-1) {
			stopPath(p + 'D',maze, r + 1, c + 1);

		}
		if (r < maze.length-1) {
			stopPath(p + 'V',maze, r + 1, c);

		}
		if (c < maze[0].length-1) {
			stopPath(p + 'H',maze, r, c + 1);
		}
		
	}
	
	static void restrictPath(String p,boolean[][] maze, int r, int c) {
		if (r == maze.length-1 && c == maze[0].length-1) {
			System.out.println(p);
			return;
		}
		if(maze[r][c]==false) {
			return;
		}
		if (r < maze.length-1 && c < maze[0].length-1) {
			restrictPath(p + 'D',maze, r + 1, c + 1);

		}
		if (r < maze.length-1) {
			restrictPath(p + 'V',maze, r + 1, c);

		}
		if (c < maze[0].length-1) {
			restrictPath(p + 'H',maze, r, c + 1);
		}
	
	}
	
}
