package basicJava;

public class OtherClass {

	public static void main(String[] args) {
		
		StringConcatenate sc=new StringConcatenate();
		
		sc.concatenatedText();

	}

}
