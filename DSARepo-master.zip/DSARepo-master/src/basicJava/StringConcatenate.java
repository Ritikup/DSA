package basicJava;

public class StringConcatenate {

	public static void main(String[] args) {
		
		//concatenatedText();
//		String con2=concatenatedText();
//		
//		System.out.println(con2);
		
		System.out.println(concatenatedText());

	}
	
	public static String concatenatedText() {
		
		String f="DSA";
		String s="Section B";
		
		//System.out.println(f+" "+s);
		
		String con=f+" "+s;
		
		return con;
		
		
	}

}
