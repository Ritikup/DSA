package basicJava;

public class ObjectCreation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i=1;  //primitive
		char c='a';
		double f=1.2;
		
		String s="DSA-Section-A"; //non-primitive
		
		String sc=new String(s);
		
		System.out.println(sc.toUpperCase());
		System.out.println(sc.toLowerCase());
		

	}

}
